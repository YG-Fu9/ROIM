function end_loop = detect_end_loop(dataDir)
files = dir(fullfile(dataDir, 'alpha_full_*.txt'));
if isempty(files)
    error('No alpha_full_*.txt found in %s', dataDir);
end

loops = zeros(numel(files),1);
for i = 1:numel(files)
    tok = regexp(files(i).name, '^alpha_full_(\d+)\.txt$', 'tokens', 'once');
    if isempty(tok)
        error('Unexpected filename: %s', files(i).name);
    end
    loops(i) = str2double(tok{1});
end

end_loop = max(loops);
end
