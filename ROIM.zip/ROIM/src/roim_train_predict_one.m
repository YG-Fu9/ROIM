function pred = roim_train_predict_one(cache, dataDir, loop, cfg)
% alpha -> (u,v,p) or (u,v,w,p)
% k     -> T (only when cfg.has_k && cfg.has_T)

N    = cfg.train_count;
Npts = cache.Npts;
col  = cache.col;

% weights
w     = linspace(cfg.min_w, cfg.max_w, N)';  % N x 1
w_nor = w ./ sum(w);
lambda = cfg.lambda_reg;

pred.coords = cache.coords;

% ---------- alpha PCA ----------
X_alpha = cache.X_alpha;                 % Npts x N
meanX_alpha = X_alpha * w_nor;
Xc_alpha_tr = X_alpha - meanX_alpha;

Xa_w = Xc_alpha_tr * diag(sqrt(w));
[Ua, Sa, Va] = svd(Xa_w, 'econ');
k_a = size(Sa,1);
Pa  = Ua(:,1:k_a);
Ca  = Sa(1:k_a,1:k_a) * Va(:,1:k_a)';    % k_a x N

% alpha test
A_te = readmatrix(fullfile(dataDir, sprintf(cfg.alpha_pat, loop)));
alpha_te = A_te(:, cfg.alpha_col);
if cfg.use_log_alpha
    Xalpha_te = log(1 + alpha_te);
else
    Xalpha_te = alpha_te;
end
Xc_alpha_te = Xalpha_te - meanX_alpha;
Ca_te = Pa' * Xc_alpha_te;               % k_a x 1

% ---------- alpha -> flow vars ----------
for vi = 1:numel(cfg.pred_vars)
    vname = cfg.pred_vars{vi};

    if strcmp(vname,'T')
        continue; % T handled by k->T below
    end

    % build training Y (Npts x N)
    c = col.(vname);                      % column index in field file
    Y = zeros(Npts, N);
    for j = 1:N
        Uj = cache.Uraw(:,:,j);
        Y(:,j) = Uj(:, c);
    end

    % center + POD
    meanY = Y * w_nor;
    Yc_tr = Y - meanY;

    Yw = Yc_tr * diag(sqrt(w));
    [Uy, Sy, Vy] = svd(Yw, 'econ');
    k_y = min(k_a, size(Sy,1));
    Py  = Uy(:,1:k_y);
    Cy  = Sy(1:k_y,1:k_y) * Vy(:,1:k_y)'; % k_y x N

    % ridge mapping (latent)
    W = (Ca*Ca' + lambda*eye(size(Ca,1))) \ (Ca*Cy');  % (k_a x k_y)
    Cy_te = W' * Ca_te;                                % k_y x 1

    % reconstruct
    pred.(vname) = Py * Cy_te + meanY;
end

% ---------- k -> T ----------
if cfg.has_k && cfg.has_T
    if ~isfield(col,'T')
        error('Config mismatch: has_T=true but colmap has no T.');
    end

    % PCA on k
    X_k = cache.X_k;                      % Npts x N
    meanX_k = X_k * w_nor;
    Xc_k_tr = X_k - meanX_k;

    Xk_w = Xc_k_tr * diag(sqrt(w));
    [Uk, Sk, Vk] = svd(Xk_w, 'econ');
    k_k = size(Sk,1);
    Pk  = Uk(:,1:k_k);
    Ck  = Sk(1:k_k,1:k_k) * Vk(:,1:k_k)'; % k_k x N

    % POD on T
    cT = col.T;
    YT = zeros(Npts, N);
    for j = 1:N
        Uj = cache.Uraw(:,:,j);
        YT(:,j) = Uj(:, cT);
    end

    meanYT = YT * w_nor;
    YcT_tr = YT - meanYT;

    YwT = YcT_tr * diag(sqrt(w));
    [UT, ST, VT] = svd(YwT, 'econ');
    k_T = min(k_k, size(ST,1));
    PT  = UT(:,1:k_T);
    CT  = ST(1:k_T,1:k_T) * VT(:,1:k_T)'; % k_T x N

    WT = (Ck*Ck' + lambda*eye(size(Ck,1))) \ (Ck*CT');  % (k_k x k_T)

    % test k
    K_te = readmatrix(fullfile(dataDir, sprintf(cfg.k_pat, loop)));
    xk_te = K_te(:, cfg.k_col);
    Xc_k_te = xk_te - meanX_k;
    Ck_te = Pk' * Xc_k_te;               % k_k x 1

    CT_te = WT' * Ck_te;                 % k_T x 1
    pred.T = PT * CT_te + meanYT;
end

end
