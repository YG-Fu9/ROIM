function res = roim_predict_case(dataDir, outDir, cfg)
% Predict vars for loops (start_loop+N) ... end_loop

N = cfg.train_count;
init_loop = cfg.start_loop + N;

if cfg.end_loop < init_loop
    error('Not enough loops. end_loop=%d < init_loop=%d (start_loop=%d, N=%d).', ...
        cfg.end_loop, init_loop, cfg.start_loop, N);
end

loops = init_loop:cfg.end_loop;
Npred = numel(loops);

res.loops = loops(:);
res.smape = struct();

% prealloc smape arrays
for i = 1:numel(cfg.pred_vars)
    vname = cfg.pred_vars{i};
    res.smape.(vname) = nan(Npred,1);
end

cache = [];
col = get_field_colmap(cfg);

tag = strjoin(cfg.pred_vars,''); % uvp / uvpT / uvwp / uvwpT

for ii = 1:Npred
    loop = loops(ii);

    % update cache for this loop
    cache = roim_update_cache(cache, dataDir, loop, cfg);

    % train + predict
    pred = roim_train_predict_one(cache, dataDir, loop, cfg);

    % truth for metrics
    truth = readmatrix(fullfile(dataDir, sprintf(cfg.field_pat, loop)));

    % compute smape per variable (MUST use temp array for dynamic field)
    for vi = 1:numel(cfg.pred_vars)
        vname = cfg.pred_vars{vi};

        y_true = truth(:, col.(vname));
        y_pred = pred.(vname);

        s = roim_smape(y_true, y_pred, cfg.eps_smape);

        tmp = res.smape.(vname);  % <-- temp
        tmp(ii) = s;
        res.smape.(vname) = tmp;  % <-- write back
    end

    % write predicted fields
    if cfg.write_fields
        outMat = pred.coords;
        for vi = 1:numel(cfg.pred_vars)
            vname = cfg.pred_vars{vi};
            outMat = [outMat, pred.(vname)]; %#ok<AGROW>
        end
        outFile = fullfile(outDir, 'fields', sprintf('%s_pred_%d.txt', tag, loop));
        writematrix(outMat, outFile, 'Delimiter','\t');
    end

    % log (also MUST use temp array)
    fprintf('Loop %d | ', loop);
    for vi = 1:numel(cfg.pred_vars)
        vname = cfg.pred_vars{vi};
        tmp = res.smape.(vname);
        fprintf('SMAPE_%s=%.3f%% ', vname, tmp(ii));
    end
    fprintf('\n');
end

% write metrics
if cfg.write_metrics
    metricFile = fullfile(outDir, 'metrics', 'smape_per_loop.txt');
    fid = fopen(metricFile,'w');

    fprintf(fid, 'loop');
    for vi = 1:numel(cfg.pred_vars)
        fprintf(fid, '\tsmape_%s(%%)', cfg.pred_vars{vi});
    end
    fprintf(fid, '\n');

    for ii = 1:Npred
        fprintf(fid, '%d', loops(ii));
        for vi = 1:numel(cfg.pred_vars)
            vname = cfg.pred_vars{vi};
            tmp = res.smape.(vname);
            fprintf(fid, '\t%.8f', tmp(ii));
        end
        fprintf(fid, '\n');
    end
    fclose(fid);

    avgFile = fullfile(outDir, 'metrics', 'smape_avg.txt');
    fid = fopen(avgFile,'w');

    fprintf(fid, 'avg');
    for vi = 1:numel(cfg.pred_vars)
        fprintf(fid, '\tavg_smape_%s(%%)', cfg.pred_vars{vi});
    end
    fprintf(fid, '\n');

    fprintf(fid, 'value');
    for vi = 1:numel(cfg.pred_vars)
        vname = cfg.pred_vars{vi};
        tmp = res.smape.(vname);
        fprintf(fid, '\t%.8f', mean(tmp,'omitnan'));
    end
    fprintf(fid, '\n');
    fclose(fid);
end

end
