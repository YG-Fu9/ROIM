function s = roim_smape(y_true, y_pred, eps0)
if nargin < 3; eps0 = 1e-4; end
y_true = y_true(:);
y_pred = y_pred(:);
den = (abs(y_true) + abs(y_pred))/2 + eps0;
s = mean(abs(y_true - y_pred) ./ den) * 100;
end
