function cfg = get_case_config(caseName)
% GET_CASE_CONFIG  Per-case settings (file patterns, dimensions, weights, variables)

cfg = struct();

% ----- shared defaults -----
cfg.name          = caseName;
cfg.start_loop    = 2;         % ignore loop=1
cfg.end_loop      = [];        % auto-detect later
cfg.use_log_alpha = true;

cfg.lambda_reg    = 1e-10;     % ridge regularization in latent mapping
cfg.eps_smape     = 1e-4;

% file patterns (alpha always the same)
cfg.alpha_pat = 'alpha_full_%d.txt';
cfg.k_pat     = 'ks_full_%d.txt';     % used only when has_k = true
cfg.field_pat = '';                  % per case

% columns in alpha/k files
cfg.alpha_col = 3;
cfg.k_col     = 3;

% output switches
cfg.write_fields  = true;
cfg.write_metrics = true;

switch caseName
    case '2D_heat'
        cfg.train_count = 9;
        cfg.min_w       = 0.5;
        cfg.max_w       = 1.5;

        cfg.coord_dim   = 2;
        cfg.has_T       = true;
        cfg.has_k       = true;               % k -> T
        cfg.pred_vars   = {'u','v','p','T'};  % alpha->u,v,p ; k->T
        cfg.field_pat   = 'uvpT_full_%d.txt';

    case '2D_multiinlet_flow'
        cfg.train_count = 13;
        cfg.min_w       = 0.2;
        cfg.max_w       = 2.0;

        cfg.coord_dim   = 2;
        cfg.has_T       = false;
        cfg.has_k       = false;
        cfg.pred_vars   = {'u','v','p'};
        cfg.field_pat   = 'uvp_full_%d.txt';

    case '3D_flow'
        cfg.train_count = 8;
        cfg.min_w       = 0.5;
        cfg.max_w       = 1.5;

        cfg.coord_dim   = 3;
        cfg.has_T       = false;
        cfg.has_k       = false;
        cfg.pred_vars   = {'u','v','w','p'};
        cfg.field_pat   = 'uvwp_full_%d.txt';

    case '3D_heat'
        cfg.train_count = 4;
        cfg.min_w       = 1.0;
        cfg.max_w       = 1.0;

        cfg.coord_dim   = 3;
        cfg.has_T       = true;
        cfg.has_k       = true;                 % k -> T
        cfg.pred_vars   = {'u','v','w','p','T'};
        cfg.field_pat   = 'uvwpT_full_%d.txt';

    otherwise
        error('Unknown caseName: %s', caseName);
end

% sanity checks
if cfg.has_T == false && any(strcmp(cfg.pred_vars,'T'))
    error('Config error: pred_vars contains T but has_T=false for case %s', caseName);
end
if cfg.has_k == false && any(strcmp(cfg.pred_vars,'T'))
    error('Config error: T requested but has_k=false (your rule is k->T). Case=%s', caseName);
end

end
