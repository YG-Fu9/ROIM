function cache = roim_update_cache(cache, dataDir, loop, cfg)
% Cache training data for loops [loop-N, ..., loop-1] (sliding window)

N   = cfg.train_count;
ref = loop - 1;

need_init = isempty(cache) || ~isfield(cache,'last_ref');

if need_init
    % read reference field file to get sizes + coords
    Uref = readmatrix(fullfile(dataDir, sprintf(cfg.field_pat, ref)));
    col  = get_field_colmap(cfg);

    cache.Npts   = size(Uref,1);
    cache.ncols  = size(Uref,2);
    cache.coords = Uref(:, col.coords);
    cache.col    = col;

    cache.X_alpha = zeros(cache.Npts, N);
    if cfg.has_k
        cache.X_k = zeros(cache.Npts, N);
    else
        cache.X_k = [];
    end

    cache.Uraw = zeros(cache.Npts, cache.ncols, N);

    for j = 1:N
        L = loop - N + j - 1;

        A = readmatrix(fullfile(dataDir, sprintf(cfg.alpha_pat, L)));
        alpha = A(:, cfg.alpha_col);
        if cfg.use_log_alpha
            cache.X_alpha(:,j) = log(1 + alpha);
        else
            cache.X_alpha(:,j) = alpha;
        end

        if cfg.has_k
            K = readmatrix(fullfile(dataDir, sprintf(cfg.k_pat, L)));
            cache.X_k(:,j) = K(:, cfg.k_col);
        end

        U = readmatrix(fullfile(dataDir, sprintf(cfg.field_pat, L)));
        cache.Uraw(:,:,j) = U;
    end

    cache.last_ref = ref;
    return;
end

% already updated for this loop?
if cache.last_ref == ref
    return;
end

% consecutive slide update
if cache.last_ref == ref - 1
    A_new = readmatrix(fullfile(dataDir, sprintf(cfg.alpha_pat, ref)));
    alpha = A_new(:, cfg.alpha_col);
    if cfg.use_log_alpha
        xalpha_new = log(1 + alpha);
    else
        xalpha_new = alpha;
    end
    cache.X_alpha = [cache.X_alpha(:,2:end), xalpha_new];

    if cfg.has_k
        K_new = readmatrix(fullfile(dataDir, sprintf(cfg.k_pat, ref)));
        cache.X_k = [cache.X_k(:,2:end), K_new(:, cfg.k_col)];
    end

    U_new = readmatrix(fullfile(dataDir, sprintf(cfg.field_pat, ref)));
    cache.Uraw = cat(3, cache.Uraw(:,:,2:end), U_new);

    cache.last_ref = ref;
else
    % not consecutive -> re-init safely
    cache = [];
    cache = roim_update_cache(cache, dataDir, loop, cfg);
end

end
