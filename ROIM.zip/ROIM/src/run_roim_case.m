function run_roim_case(caseName)
% RUN_ROIM_CASE  Run ROIM prediction for one selected case.
%
% Example:
%   run_roim_case('2D_heat')
%   run_roim_case('3D_flow')

clc;

if nargin < 1 || isempty(caseName)
    error("Usage: run_roim_case('2D_heat') / run_roim_case('2D_multiinlet_flow') / run_roim_case('3D_flow') / run_roim_case('3D_heat')");
end

% repo root: ROIM/
rootDir  = fileparts(fileparts(mfilename('fullpath')));
dataRoot = fullfile(rootDir, 'Data');
outRoot  = fullfile(rootDir, 'Output');

cfg = get_case_config(caseName);

dataDir = fullfile(dataRoot, cfg.name);
if ~exist(dataDir, 'dir')
    error('Data folder not found: %s', dataDir);
end

cfg.end_loop = detect_end_loop(dataDir);  % scan alpha_full_*.txt

outDir = fullfile(outRoot, cfg.name);
if ~exist(outDir, 'dir'); mkdir(outDir); end
if ~exist(fullfile(outDir,'fields'),  'dir'); mkdir(fullfile(outDir,'fields')); end
if ~exist(fullfile(outDir,'metrics'), 'dir'); mkdir(fullfile(outDir,'metrics')); end

fprintf('\n========== ROIM Case: %s ==========\n', cfg.name);
fprintf('Detected end_loop: %d\n', cfg.end_loop);
fprintf('N=%d, min_w=%.2f, max_w=%.2f\n', cfg.train_count, cfg.min_w, cfg.max_w);
fprintf('coord_dim=%d, has_T=%d, has_k=%d, pred_vars=%s\n', ...
    cfg.coord_dim, cfg.has_T, cfg.has_k, strjoin(cfg.pred_vars, ','));
fprintf('field_pat=%s\n', cfg.field_pat);
fprintf('====================================\n');

res = roim_predict_case(dataDir, outDir, cfg);

fprintf('\nAvg SMAPE (%%):\n');
for i = 1:numel(cfg.pred_vars)
    vname = cfg.pred_vars{i};
    fprintf('  %s: %.6f\n', vname, mean(res.smape.(vname), 'omitnan'));
end
fprintf('\nDone.\n');
end
