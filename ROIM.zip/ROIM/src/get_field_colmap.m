function col = get_field_colmap(cfg)
% Unified field file columns:
% 2D flow : [x y u v p]
% 2D heat : [x y u v p T]
% 3D flow : [x y z u v w p]
% 3D heat : [x y z u v w p T]

if cfg.coord_dim == 2
    col.coords = 1:2;
    col.u = 3; col.v = 4; col.p = 5;
    if cfg.has_T
        col.T = 6;
    end

elseif cfg.coord_dim == 3
    col.coords = 1:3;
    col.u = 4; col.v = 5; col.w = 6; col.p = 7;
    if cfg.has_T
        col.T = 8;
    end

else
    error('Unsupported coord_dim: %d', cfg.coord_dim);
end

end
